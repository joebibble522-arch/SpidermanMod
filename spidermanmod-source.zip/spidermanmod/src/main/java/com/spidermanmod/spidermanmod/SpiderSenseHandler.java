package com.spidermanmod.spidermanmod;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

public class SpiderSenseHandler {

    // Sense radius in blocks
    private static final double SENSE_RANGE = 16.0;
    // How often to check (every N ticks, 20 ticks = 1 second)
    private static final int CHECK_INTERVAL = 40;
    // Track last alert time per player so we don't spam
    private final Map<UUID, Long> lastAlertTick = new HashMap<>();

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Player player = event.player;
        if (player.level().isClientSide()) return;

        // Only activate if holding web shooter in main hand
        ItemStack heldItem = player.getMainHandItem();
        if (!(heldItem.getItem() instanceof WebShooterItem)) return;

        long currentTick = player.level().getGameTime();
        UUID playerId = player.getUUID();

        // Throttle checks
        if (currentTick % CHECK_INTERVAL != 0) return;

        Long lastAlert = lastAlertTick.getOrDefault(playerId, 0L);
        // Don't alert more than once every 2 seconds (40 ticks)
        if (currentTick - lastAlert < 40) return;

        // Find hostile mobs nearby
        List<Monster> nearbyMonsters = player.level().getEntitiesOfClass(
                Monster.class,
                player.getBoundingBox().inflate(SENSE_RANGE),
                mob -> mob.isAlive() && !mob.isDeadOrDying()
        );

        if (!nearbyMonsters.isEmpty()) {
            // Play a high-pitched "tingle" sound
            player.level().playSound(null, player.blockPosition(),
                    SoundEvents.NOTE_BLOCK_BELL.get(),
                    SoundSource.PLAYERS, 0.6f, 2.0f);

            // Send a chat warning message
            player.displayClientMessage(
                    net.minecraft.network.chat.Component.literal(
                            "§c⚠ Spider-Sense tingles! §7(" + nearbyMonsters.size() + " nearby)"
                    ), true // true = display in action bar above hotbar
            );

            lastAlertTick.put(playerId, currentTick);
        }
    }
}
