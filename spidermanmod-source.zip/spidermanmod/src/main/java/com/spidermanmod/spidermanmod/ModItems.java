package com.spidermanmod.spidermanmod;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SpiderManMod.MODID);

    public static final RegistryObject<Item> WEB_SHOOTER =
            ITEMS.register("web_shooter", WebShooterItem::new);
}
