package com.spidermanmod.spidermanmod;

import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(SpiderManMod.MODID)
public class SpiderManMod {

    public static final String MODID = "spidermanmod";
    private static final Logger LOGGER = LogUtils.getLogger();

    public SpiderManMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modEventBus);

        MinecraftForge.EVENT_BUS.register(new SpiderSenseHandler());
        MinecraftForge.EVENT_BUS.register(new WallClimbHandler());

        LOGGER.info("Spider-Man Mod loaded!");
    }
}
