package com.spidermanmod.spidermanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class WallClimbHandler {

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Player player = event.player;
        if (player.level().isClientSide()) return;

        // Only if holding web shooter
        ItemStack heldItem = player.getMainHandItem();
        if (!(heldItem.getItem() instanceof WebShooterItem)) return;

        // Check if player is pressed against a wall
        if (isAgainstWall(player) && !player.onGround()) {
            Vec3 motion = player.getDeltaMovement();

            // Cancel downward gravity while touching wall
            if (motion.y < 0) {
                player.setDeltaMovement(motion.x, 0, motion.z);
            }

            // Allow climbing up by pressing forward into the wall
            if (player.zza > 0) { // player is pressing W
                player.setDeltaMovement(motion.x, 0.2, motion.z);
            }

            // Reset fall distance so no fall damage after dismounting
            player.fallDistance = 0;
        }

        // After swinging, cancel fall damage on landing if still holding item
        // (we reset fallDistance every tick while holding — effectively no fall damage)
        if (player.onGround()) {
            player.fallDistance = 0;
        }
    }

    private boolean isAgainstWall(Player player) {
        BlockPos pos = player.blockPosition();
        int x = pos.getX();
        int y = pos.getY();
        int z = pos.getZ();

        // Check the 4 cardinal directions for a solid block at body height
        BlockPos[] neighbors = {
            new BlockPos(x + 1, y, z),
            new BlockPos(x - 1, y, z),
            new BlockPos(x, y, z + 1),
            new BlockPos(x, y, z - 1),
        };

        for (BlockPos neighbor : neighbors) {
            if (player.level().getBlockState(neighbor).isSolidRender(
                    player.level(), neighbor)) {
                return true;
            }
        }
        return false;
    }
}
