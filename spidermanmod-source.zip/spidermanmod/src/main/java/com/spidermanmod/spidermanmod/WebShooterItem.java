package com.spidermanmod.spidermanmod;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class WebShooterItem extends Item {

    // Max swing range in blocks
    private static final double MAX_RANGE = 50.0;
    // How fast you get launched toward the target
    private static final double LAUNCH_POWER = 3.5;

    public WebShooterItem() {
        super(new Item.Properties().stacksTo(1));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);

        if (!level.isClientSide) {
            // Raycast from where the player is looking
            Vec3 eyePos = player.getEyePosition();
            Vec3 lookVec = player.getLookAngle();
            Vec3 reach = eyePos.add(lookVec.scale(MAX_RANGE));

            BlockHitResult hit = level.clip(new ClipContext(
                    eyePos, reach,
                    ClipContext.Block.SOLID,
                    ClipContext.Fluid.NONE,
                    player
            ));

            if (hit.getType() == HitResult.Type.BLOCK) {
                BlockPos targetPos = hit.getBlockPos();
                Vec3 target = Vec3.atCenterOf(targetPos);

                // Vector from player to target
                Vec3 toTarget = target.subtract(player.position()).normalize();

                // Launch the player toward the target
                player.setDeltaMovement(
                        toTarget.x * LAUNCH_POWER,
                        Math.max(toTarget.y * LAUNCH_POWER, 0.8), // always give a bit of upward boost
                        toTarget.z * LAUNCH_POWER
                );

                // Disable fall damage briefly by giving player a short levitation boost moment
                player.fallDistance = 0;

                // Play a "thwip" sound using bow sound as closest match
                level.playSound(null, player.blockPosition(),
                        SoundEvents.FISHING_BOBBER_THROW,
                        SoundSource.PLAYERS, 1.0f, 0.5f);

                // Reset fall distance so they don't die when landing (handled in WallClimbHandler)
                player.getCapabilities().ifPresent(cap -> {});
            } else {
                // Missed — play a sad little click
                level.playSound(null, player.blockPosition(),
                        SoundEvents.DISPENSER_FAIL,
                        SoundSource.PLAYERS, 0.5f, 1.2f);
            }
        }

        return InteractionResultHolder.sidedSuccess(itemStack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Right-click a surface to swing!"));
        tooltip.add(Component.literal("Hold to climb walls & sense danger."));
    }
}
